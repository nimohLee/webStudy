/* 
filter
1. 데이터를 걸러내어 배열로 return
2. 사용방법은 forEach와 거의 동일
3. filter + forEach
*/

const array = [1, 2, 3, 4, 5, 6, 7, 8, 9];
const result = array.filter((arr)=>{
    /* return 뒤에 걸러낼 조건 */
    return arr % 2 == 0; // 2로 나눈 나머지가 0인 것(짝수) 모아서 배열로 return
});
result.forEach(arr => console.log(arr));


/* chaining method */
/* 위에 filter한 거랑 forEach 합친다는 뜻
filter한 결과가 forEach에 그냥 굳이 나눠서 할필요없이 Chain(체인)으로 건다는 거 
filter랑 forEach뿐만아니라 이렇게 메서드 계속 이어나가는 걸 체이닝 메서드(chaining method)이라고 함*/
const result2 = array.filter((arr)=>{
    return arr % 2 == 0;
}).forEach(arr => console.log(arr));

const users = [
    {id: 1, username: 'KIM', auth: false},
    {id: 2, username: 'PARK', auth: true},
    {id: 3, username: 'CHOI', auth: false}
];

const result02 = users.filter( (user) => {
    return user.auth == false; // filter는 배열을 리턴함
}).forEach(arr => console.log(arr));

/* const result02 = 근데 밑에서 console.log를 직접해주기 때문에 변수로 안해도 출력됨*/
users.filter( (user) => {
    return user.auth == false; // filter는 배열을 리턴함
}).forEach(arr => console.log(arr.username+"님은 접근하실 수 없습니다;;"));

users.filter((user) => user.auth == false)
    .forEach(u => console.log("Access denied : " + u.username));